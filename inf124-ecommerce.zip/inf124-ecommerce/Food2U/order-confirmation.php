<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Order Confirmation</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <meta http-equiv="refresh" content="60" />
  <link rel="stylesheet" type="text/css" href="css/default.css" />
</head>

<body>
  <div id="page">
    <?php include("common/mainmenu.html");?>

    <div class="main" align="center">
      <h1>Your Order Has Been Received!!</h1>
      <h3>An email has been sent to you as confirmation.</h3>
      <h4>You will receive a call upon delivery.</h4>

    </div>
  </div>
</body>
</html>
