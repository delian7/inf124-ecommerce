# inf124-ecommerce
Informatics 124 - Ecommerce Website

Delian Petrov - 14131359
Michael Oh - 64776531

Link to website at: https://students.ics.uci.edu/~petrovd/inf124-ecommerce/index.php

We wanted to note that the feedback & receipt logs (in data folder) did not work on Heroku nor the ICS Server, however it worked for both of us locally. 